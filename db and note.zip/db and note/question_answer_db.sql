-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2021 at 05:53 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `question_answer_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `date_updated`) VALUES
(1, 'General Questions', 'General Questions', '2021-09-11 16:44:10'),
(2, 'Programming', 'Programming Questions', '2021-09-11 10:07:53'),
(3, 'Networking and Hardware', 'Networking and Hardware Questions', '2021-09-11 10:07:53'),
(4, 'Mathematics', 'Mathematics Questions', '2021-09-11 16:45:08');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(30) NOT NULL,
  `topic_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `comment` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `topic_id`, `user_id`, `comment`, `date_created`, `date_updated`) VALUES
(1, 1, 4, 'Computer science, the study of computers and computing, including their theoretical and algorithmic foundations, hardware and software, and their uses for processing information.', '2021-09-11 15:50:33', '2021-09-11 15:50:33'),
(2, 5, 2, '&lt;span style=&quot;color: rgb(77, 81, 86); font-family: arial, sans-serif;&quot;&gt;A computer network is a set of computers sharing resources located on or provided by network nodes. The computers use common communication protocols over digital interconnections to communicate with each other.&lt;/span&gt;', '2021-09-11 16:01:06', '2021-09-11 16:01:06'),
(3, 2, 4, 'IPv4 is 32-Bit IP address whereas IPv6 is a 128-Bit IP address.', '2021-09-11 16:51:14', '2021-09-11 16:51:14');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(30) NOT NULL,
  `category_ids` text NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `user_id` int(30) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `category_ids`, `title`, `content`, `user_id`, `date_created`) VALUES
(1, '1', 'Computer Science', 'What is Computer Science ?', 2, '2021-09-11 10:36:47'),
(2, '3', 'Networking', 'How do I differentiate between ipv4 and ipv6 ?', 3, '2021-09-11 10:53:25'),
(3, '1', 'Mathematics', 'Solve for x in the equation: x&lt;sup&gt;2&lt;/sup&gt; + 2x&lt;sup&gt;2&lt;/sup&gt; - 7 = 0', 3, '2021-09-11 11:55:01'),
(4, '2', 'PHP', 'How do you find the length of a string in PHP ?', 2, '2021-09-11 15:39:07'),
(5, '3', 'Networking', 'What is Networking ?', 4, '2021-09-11 15:47:09'),
(6, '1,2', 'Computer Science', 'What is an Algorithm and explain Data Structures', 3, '2021-09-11 16:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `question_views`
--

CREATE TABLE `question_views` (
  `id` int(30) NOT NULL,
  `topic_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question_views`
--

INSERT INTO `question_views` (`id`, `topic_id`, `user_id`) VALUES
(1, 2, 2),
(2, 3, 2),
(3, 1, 4),
(4, 5, 2),
(5, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(30) NOT NULL,
  `comment_id` int(30) NOT NULL,
  `reply` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`id`, `comment_id`, `reply`, `user_id`, `date_created`, `date_updated`) VALUES
(1, 2, 'Computer science is the study of computers and computing as well as their theoretical and practical applications.', 3, '2021-09-11 16:31:48', '2021-09-11 16:47:42'),
(2, 3, '&lt;span style=&quot;color: rgb(32, 33, 36); font-family: arial, sans-serif; font-size: 16px;&quot;&gt;&amp;nbsp;IPv4 is a numeric addressing method whereas IPv6 is an alphanumeric addressing method&lt;/span&gt;', 4, '2021-09-11 16:51:32', '2021-09-11 16:51:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 3 COMMENT '1=Administrator,2=Users,3=Others'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`) VALUES
(1, 'Administrator', 'administrator', 'e807f1fcf82d132f9bb018ca6738a19f', 1),
(2, 'Temitope Fagborun', 'flashsystems', 'e807f1fcf82d132f9bb018ca6738a19f', 2),
(3, 'Oyindamola Oyelakin', 'nifty', 'e6b9d030f959799d4fd8682c5f40289e', 2),
(4, 'Adebayo Hammed', 'hammed', '1440678686300af80cd5f3370ebbe54b', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_views`
--
ALTER TABLE `question_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `question_views`
--
ALTER TABLE `question_views`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
